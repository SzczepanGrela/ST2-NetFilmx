﻿namespace NetFilmx_Service.Dtos.Category
{
    public interface ICategoryDto
    {
    }
}
