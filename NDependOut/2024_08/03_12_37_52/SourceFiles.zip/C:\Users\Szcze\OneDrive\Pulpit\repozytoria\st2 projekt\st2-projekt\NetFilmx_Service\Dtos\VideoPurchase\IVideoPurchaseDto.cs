﻿namespace NetFilmx_Service.Dtos.VideoPurchase
{
    public interface IVideoPurchaseDto
    {
    }
}
