﻿namespace NetFilmx_Service.Dtos.Comment
{
    public interface ICommentDto
    {
    }
}
