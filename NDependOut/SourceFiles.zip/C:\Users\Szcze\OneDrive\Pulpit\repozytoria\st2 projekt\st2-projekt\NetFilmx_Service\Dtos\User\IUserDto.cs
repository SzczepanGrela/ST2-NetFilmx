﻿namespace NetFilmx_Service.Dtos.User
{
    public interface IUserDto
    {
    }
}
