﻿namespace NetFilmx_Service.Dtos.Like
{
    public interface ILikeDto
    {
    }
}
