﻿namespace NetFilmx_Service.Dtos.SeriesPurchase
{
    public interface ISeriesPurchaseDto
    {
    }
}
