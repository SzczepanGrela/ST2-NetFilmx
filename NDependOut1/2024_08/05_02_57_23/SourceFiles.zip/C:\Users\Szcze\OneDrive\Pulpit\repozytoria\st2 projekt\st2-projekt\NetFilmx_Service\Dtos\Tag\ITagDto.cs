﻿namespace NetFilmx_Service.Dtos.Tag
{
    public interface ITagDto
    {
    }
}
