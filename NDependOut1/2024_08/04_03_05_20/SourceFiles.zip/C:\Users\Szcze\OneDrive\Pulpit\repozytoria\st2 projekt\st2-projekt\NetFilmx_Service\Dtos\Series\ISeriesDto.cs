﻿namespace NetFilmx_Service.Dtos.Series
{
    public interface ISeriesDto
    {
    }
}
