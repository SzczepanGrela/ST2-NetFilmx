﻿namespace NetFilmx_Service.Dtos.Video
{
    public interface IVideoDto
    {
    }
}
