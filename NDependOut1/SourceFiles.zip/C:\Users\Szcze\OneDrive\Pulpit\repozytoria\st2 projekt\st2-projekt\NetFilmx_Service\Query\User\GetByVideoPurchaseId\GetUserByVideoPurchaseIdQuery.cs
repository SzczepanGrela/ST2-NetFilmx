﻿using MediatR;

namespace NetFilmx_Service.Query.User
{
    public sealed class GetUserByVideoPurchaseIdQuery<TDto> : IRequest<QResult<TDto>>
    {
        public GetUserByVideoPurchaseIdQuery(int videoPurchaseId)
        {
            VideoPurchaseId = videoPurchaseId;
        }
        public int VideoPurchaseId { get; }

    }
}
